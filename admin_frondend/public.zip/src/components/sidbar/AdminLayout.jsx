import { useNavigate, useLocation, Outlet } from "react-router-dom";
import AdminSidebar from "./AdminSidebar";


// maps sidebar "key" -> actual route path
const ROUTE_MAP = {
  dashboard: "/dashboard",
  sellers: "/sellers",
  users: "/users",
  categories: "/categories",
  products: "/products",
  orders: "/orders",
  reviews: "/reviews",
  profile: "/profile",
};

// reverse lookup: current pathname -> which sidebar key should highlight
const getActiveKey = (pathname) => {
  const match = Object.entries(ROUTE_MAP).find(([, path]) =>
    path === "/admin" ? pathname === "/admin" : pathname.startsWith(path)
  );
  return match ? match[0] : "dashboard";
};

export default function AdminLayout() {
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavigate = (key) => {
    navigate(ROUTE_MAP[key]);
  };

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <div className="flex min-h-screen bg-[#0F1320]">
      <AdminSidebar
        active={getActiveKey(location.pathname)}
        onNavigate={handleNavigate}
        onLogout={handleLogout}
        adminName="Rahul"
      />
      <main className="flex-1 p overflow-y-auto">

        <Outlet />
      </main>
    </div>
  );
}